package com.ashish.screenshot;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map.Entry;

import javax.imageio.ImageIO;

import lc.kra.system.keyboard.GlobalKeyboardHook;
import lc.kra.system.keyboard.event.GlobalKeyAdapter;
import lc.kra.system.keyboard.event.GlobalKeyEvent;

public class Screencapture {
	private static boolean run = true;

	public static void main(String[] args) {
		GlobalKeyboardHook keyboardHook = new GlobalKeyboardHook(true);
		System.out.println("Global keyboard hook successfully started, press [escape] key to shutdown. Connected keyboards:");

		for (Entry<Long, String> keyboard : GlobalKeyboardHook.listKeyboards().entrySet()) {
			System.out.format("%d: %s\n", keyboard.getKey(), keyboard.getValue());
		}

		keyboardHook.addKeyListener(new GlobalKeyAdapter() {

			@Override 
			public void keyPressed(GlobalKeyEvent event) {
				System.out.println("event keychar --- "+event.getKeyChar());
				
				if(event.isControlPressed() && event.getKeyChar() == 'p')
					captureScreen();
				
				if (event.getVirtualKeyCode() == GlobalKeyEvent.VK_ESCAPE) {
					run = false;
				}
			}

			private void captureScreen() {
				try { 
		            Thread.sleep(120); 
		            Robot r = new Robot(); 
		            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");  
		            LocalDateTime now = LocalDateTime.now();
		            String randomFileName = dtf.format(now).toString();
		            System.out.println("Original RandomFileName --- "+randomFileName);
		            
		            String modified = randomFileName.replaceAll(":", "");
		            System.out.println("Modified -- "+modified);
		            // It saves screenshot to desired path 
		            String path = "D://Captures//"+modified+".jpg"; 
		  
		            // Used to get ScreenSize and capture image 
		            Rectangle capture =  
		            new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()); 
		            BufferedImage Image = r.createScreenCapture(capture); 
		            ImageIO.write(Image, "jpg", new File(path)); 
		            System.out.println("Screenshot saved"); 
		        } 
		        catch (AWTException | InterruptedException | IOException ex) { 
		            System.out.println(ex); 
		        } 
			}

			@Override 
			public void keyReleased(GlobalKeyEvent event) {
				System.out.println(event); 
			}
		});

		try {
			while(run) { 
				Thread.sleep(128); 
			}
		} catch(InterruptedException e) { 
			//Do nothing
		} finally {
			keyboardHook.shutdownHook(); 
		}
	}
}


